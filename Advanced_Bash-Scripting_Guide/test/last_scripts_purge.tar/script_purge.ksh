#!/bin/ksh
# Cas du lundi
if [ "$(date +%a)" == "Mon" ] || [ "$(date +%a)" == "Tue" ] ; then
        echo "TOTO � 3 jours"
else
	echo "TOTO � 1 jour" 
fi

