#!/bin/ksh

#set -x
export DATEJOB=`date "+%Y%m%d.%H%M%S"`
export TEMP=/apps/meoatlas2/log/rapjour/rapport_rapjour${DATEJOB}.log
exec 1>$TEMP
exec 2>&1
export DATEMAIL=`date "+%d/%m/%Y � %H:%M"`
export STAT="$(hostname)_stat.vacation.${DATEJOB}"
export SAUVE_TEMP="/apps/meoatlas2/rapports/stat/Rapport_job_temp_$DATEJOB"
export SAUVE="/apps/meoatlas2/rapports/stat/$STAT"
export AUTOSERV=P20
. /etc/auto.profile
export ORACLE_SID=$(chk_auto_up | grep -i "Have Connected successfully" | head -1 | cut -d":" -f2 | cut -d"." -f1 |sed 's/ //g')
export DATE=$(date +"%Y/%m/%d %T")
export DATEVEILLE="$(TZ=CET+3 date +"%Y/%m/%d %T")"
export FILE=/tmp/envoiemail.ma

#Lancement du script perl qui check tous le jobs en cours, running ou failure

#/apps/meoatlas2/autosys/autosys_rapjour.pl -j % -f "$DATEVEILLE" -t "$DATE" |grep -v BWAEP01 >$SAUVE_TEMP
/apps/meoatlas2/autosys/autosys_rapjour.pl -j % -f "$DATEVEILLE" -t "$DATE" >$SAUVE_TEMP
RC=$?
if [[ $RC -ne 0 ]]
then
echo "Envoi du mail"

echo Subject: "Rapport envoy� � MIRB non effectu� sur la machine $(hostname)" >$FILE
print "\nBonjour,\n" >>$FILE
print "Le rapport pour injection des informations dans MIRB n'a pas �t� fait le $DATEMAIL\n" >>$FILE
print "V�rifier la log dans $TEMP\n" >>$FILE

print "Cordialement," >>$FILE
/usr/sbin/sendmail -f meo_atlas_paris -v frederic.gasnier@bnpparibas.com <$FILE
fi


#SED qui permet de rajouter les control-M pour les sauts a la ligne
if [[ -e $SAUVE_TEMP ]] then
sed '/^ *$/d' $SAUVE_TEMP >$SAUVE
fi

#S910 - CFT - transfert de fichier

             cp -p $SAUVE /tmp/$STAT
#             CFTUTIL send part=MF247000,idf=GUIREP01,fname=/tmp/$STAT,parm=$STAT
RC=$?

if [[ $RC -ne 0 ]]
then
echo "Envoi du mail"

echo Subject: "Rapport envoy� � MIRB non effectu� sur la machine $(hostname)" >$FILE
print "\nBonjour,\n" >>$FILE
print "Le rapport pour injection des informations dans MIRB est cr�� mais n'as pas �t� envoy� par CFT le $DATEMAIL\n" >>$FILE
print "V�rifier la log dans $TEMP\n" >>$FILE

print "Cordialement," >>$FILE
/usr/sbin/sendmail -f meo_atlas_paris -v frederic.gasnier@bnpparibas.com <$FILE
fi

#Purge des fichiers de logs de plus de 7 jours
cd /apps/meoatlas2/rapports/stat/
#find . -mtime +7 -exec rm {} \;

cd /apps/meoatlas2/log/rapjour/
find . -mtime +7 -exec rm {} \;


rm $SAUVE_TEMP
#Purge des fichiers de plus de 7 jours dans /tmp
find /tmp -name "$(hostname)_stat.vaca*" -mtime +7 -exec rm {} \;
