#!/bin/ksh

#export des variables
export ORACLE_DOC=$ORACLE_HOME/doc
export ORACLE_BASE=$A2_PRODUITS/oracle
export TNS_ADMIN=$A2_PRODUITS/oracle/network/admin
export NLS_LANG=AMERICAN_AMERICA.WE8ISO8859P1
export NLSPATH=$NLSPATH:$A2_BNP/exploit/msg/%L/%N:$A2_BNP/exploit/msg/%L/%N.cat
export ORACLE_BASE=/apps/oracle
export ORACLE_HOME=$ORACLE_BASE/product/11204
export LIBPATH=$ORACLE_HOME/lib:$ORACLE_HOME/precomp/public
export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/oui/bin:/usr/lbin:$PATH:.
export NLS_DATE_FORMAT='Mon DD YYYY HH24:MI:SS'

trigger () {
echo "\nListe des Triggers\n"
printf "%-65s%-11s%-17s\n" TRIGGER STATUS STARTTIME
printf "%-65s%-11s%-17s\n" ---------------------------------------------------------------- ---------- ------------------
sqlplus -s atsreader/atsreader@P10973AP10 <<EOF |egrep -v "^ERROR|^ORA|rows|JOB_NAME|---------"  | sort -nk 3 |uniq |awk '{print $1,$2,$3,$4}' >/tmp/trigger_encours
col STATUS for a10
set lines 500
set pages 200
select j.job_name,
js.text st,
to_char(to_date('01011970','DDMMYYYY')+(j.status_time-M.int_val)/86400,'DD/MM/YYYY HH24:MI:SS') debut
from
aedbadmin.ujo_jobst j , aedbadmin.ujo_intcodes js,aedbadmin.ujo_alamode M
where
M.TYPE='gmt_offset'
and j.status=js.code
and j.job_name like '%'
and status=1
and j.job_type=255
order by 3;
exit
EOF
}
triggerclasse () {
while read a b c d
do
printf "%-65s%-11s%-10s%+9s\n" $a $b $c $d
done </tmp/trigger_encours
}


encours () {
echo "\nListe des Jobs en Running\n"
printf "%-65s%-11s%-17s\n" JOB_NAME STATUS STARTTIME
printf "%-65s%-11s%-17s\n" ---------------------------------------------------------------- ---------- ------------------
sqlplus -s atsreader/atsreader@P10973AP10 <<EOF |egrep -v "^ERROR|^ORA|rows|JOB_NAME|---------"  | sort -nk 3 |uniq |awk '{print $1,$2,$3,$4}' >/tmp/job_encours
col STATUS for a10
set lines 500
set pages 200
select j.job_name,
js.text st,
to_char(to_date('01011970','DDMMYYYY')+(j.status_time-M.int_val)/86400,'DD/MM/YYYY HH24:MI:SS') debut
from
aedbadmin.ujo_jobst j , aedbadmin.ujo_intcodes js,aedbadmin.ujo_alamode M
where
M.TYPE='gmt_offset'
and j.status=js.code
and j.job_name like '%'
and status=1
and j.job_type=99
order by 3;
exit
EOF
}
encoursclasse () {
while read a b c d
do
printf "%-65s%-11s%-10s%+9s\n" $a $b $c $d
done </tmp/job_encours
}


failure () {
echo "\nListe des Jobs en failure\n"
printf "%-65s%-11s%-17s\n" JOB_NAME STATUS ENDTTIME
printf "%-65s%-11s%-17s\n" ---------------------------------------------------------------- ---------- ------------------
sqlplus -s atsreader/atsreader@P10973AP10 <<EOF |egrep -v "^ERROR|^ORA|rows|JOB_NAME|---------"  | sort -nk 3 |uniq |awk '{print $1,$2,$3,$4}' >/tmp/job_failure
col STATUS for a10
set lines 500
set pages 200
select j.job_name,
js.text st,
to_char(to_date('01011970','DDMMYYYY')+(j.status_time-M.int_val)/86400,'DD/MM/YYYY HH24:MI:SS') debut
from
aedbadmin.ujo_jobst j , aedbadmin.ujo_intcodes js,aedbadmin.ujo_alamode M
where
M.TYPE='gmt_offset'
and j.status=js.code
and j.job_name like '%'
and status=5
and j.job_type=99
order by 3;
exit
EOF
}

failureclasse () {
while read a b c d
do
if [[ -s /tmp/job_failure ]]
then
printf "%-65s%-11s%-10s%+9s\n" $a $b $c $d
else
break
fi
done </tmp/job_failure
}

success () {
echo "\nListe des Jobs SUCCESS\n"
printf "%-65s%-11s%-17s\n" JOB_NAME STATUS ENDTTIME
printf "%-65s%-11s%-17s\n" ---------------------------------------------------------------- ---------- ------------------
sqlplus -s atsreader/atsreader@P10973AP10 <<EOF |egrep -v "^ERROR|^ORA|rows|JOB_NAME|---------"  | sort -nk 3 |uniq |awk '{print $1,$2,$3,$4}' >/tmp/job_success
col STATUS for a10
set lines 500
set pages 200
select j.job_name,
js.text st,
to_char(to_date('01011970','DDMMYYYY')+(j.status_time-M.int_val)/86400,'DD/MM/YYYY HH24:MI:SS') debut
from
aedbadmin.ujo_jobst j , aedbadmin.ujo_intcodes js,aedbadmin.ujo_alamode M
where
M.TYPE='gmt_offset'
and j.status=js.code
and j.job_name like '%'
and status=4
and j.job_type=99
order by 3;
exit
EOF
}

successclasse () {
while read a b c d
do
printf "%-65s%-11s%-10s%+9s\n" $a $b $c $d
done </tmp/job_success
}

holdjob () {
echo "\nListe des Jobs Hold�s\n"
printf "%-65s%-11s%-17s\n" JOB_NAME STATUS ENDTTIME
printf "%-65s%-11s%-17s\n" ---------------------------------------------------------------- ---------- ------------------
sqlplus -s atsreader/atsreader@P10973AP10 <<EOF |egrep -v "^ERROR|^ORA|rows|JOB_NAME|---------"  | sort -nk 3 |uniq |awk '{print $1,$2,$3,$4}' >/tmp/job_holde
col STATUS for a10
set lines 500
set pages 200
select j.job_name,
js.text st,
to_char(to_date('01011970','DDMMYYYY')+(j.status_time-M.int_val)/86400,'DD/MM/YYYY HH24:MI:SS') debut
from
aedbadmin.ujo_jobst j , aedbadmin.ujo_intcodes js,aedbadmin.ujo_alamode M
where
M.TYPE='gmt_offset'
and j.status=js.code
and j.job_name like '%'
and status=11
and j.job_type=99
order by 3;
exit
EOF
}

holdjobclasse () {
while read a b c d
do
printf "%-65s%-11s%-10s%+9s\n" $a $b $c $d
done </tmp/job_holde
}

holdbox () {
echo "\nListe des BOXs hold�es\n"
printf "%-65s%-11s%-17s\n" JOB_NAME STATUS ENDTTIME
printf "%-65s%-11s%-17s\n" ---------------------------------------------------------------- ---------- ------------------
sqlplus -s atsreader/atsreader@P10973AP10 <<EOF |egrep -v "^ERROR|^ORA|rows|JOB_NAME|---------"  | sort -nk 3 |uniq |awk '{print $1,$2,$3,$4}' >/tmp/box_holde
col STATUS for a10
set lines 500
set pages 200
select j.job_name,
js.text st,
to_char(to_date('01011970','DDMMYYYY')+(j.status_time-M.int_val)/86400,'DD/MM/YYYY HH24:MI:SS') debut
from
aedbadmin.ujo_jobst j , aedbadmin.ujo_intcodes js,aedbadmin.ujo_alamode M
where
M.TYPE='gmt_offset'
and j.status=js.code
and j.job_name like '%'
and status=11
and j.job_type=98
order by 3;
exit
EOF
}


holdboxclasse () {
while read a b c d
do
printf "%-65s%-11s%-10s%+9s\n" $a $b $c $d
done </tmp/box_holde
}

icejob () {
echo "\nListe des Jobs Ic�s\n"
printf "%-65s%-11s%-17s\n" JOB_NAME STATUS ENDTTIME
printf "%-65s%-11s%-17s\n" ---------------------------------------------------------------- ---------- ------------------
sqlplus -s atsreader/atsreader@P10973AP10 <<EOF |egrep -v "^ERROR|^ORA|rows|JOB_NAME|---------"  | sort -nk 3 |uniq |awk '{print $1,$2,$3,$4}' >/tmp/job_ice
col STATUS for a10
set lines 500
set pages 200
select j.job_name,
js.text st,
to_char(to_date('01011970','DDMMYYYY')+(j.status_time-M.int_val)/86400,'DD/MM/YYYY HH24:MI:SS') debut
from
aedbadmin.ujo_jobst j , aedbadmin.ujo_intcodes js,aedbadmin.ujo_alamode M
where
M.TYPE='gmt_offset'
and j.status=js.code
and j.job_name like '%'
and status=7
and j.job_type=99
order by 3;
exit
EOF
}

icejobclasse () {
while read a b c d
do
printf "%-65s%-11s%-10s%+9s\n" $a $b $c $d
done </tmp/job_ice
}

icebox () {
echo "\nListe des BOXs Ic�s\n"
printf "%-65s%-11s%-17s\n" JOB_NAME STATUS ENDTTIME
printf "%-65s%-11s%-17s\n" ---------------------------------------------------------------- ---------- ------------------
sqlplus -s atsreader/atsreader@P10973AP10 <<EOF |egrep -v "^ERROR|^ORA|rows|JOB_NAME|---------"  | sort -nk 3 |uniq |awk '{print $1,$2,$3,$4}' >/tmp/box_ice
col STATUS for a10
set lines 500
set pages 200
select j.job_name,
js.text st,
to_char(to_date('01011970','DDMMYYYY')+(j.status_time-M.int_val)/86400,'DD/MM/YYYY HH24:MI:SS') debut
from
aedbadmin.ujo_jobst j , aedbadmin.ujo_intcodes js,aedbadmin.ujo_alamode M
where
M.TYPE='gmt_offset'
and j.status=js.code
and j.job_name like '%'
and status=7
and j.job_type=98
order by 3;
exit
EOF
}

iceboxclasse () {
while read a b c d
do
printf "%-65s%-11s%-10s%+9s\n" $a $b $c $d
done </tmp/box_ice
}

terminated () {
echo "\nListe des Jobs Terminated\n"
printf "%-65s%-11s%-17s\n" JOB_NAME STATUS ENDTTIME
printf "%-65s%-11s%-17s\n" ---------------------------------------------------------------- ---------- -------------------
sqlplus -s atsreader/atsreader@P10973AP10 <<EOF |egrep -v "^ERROR|^ORA|rows|JOB_NAME|---------"  | sort -nk 3 |uniq |awk '{print $1,$2,$3,$4}' >/tmp/job_terminated
col STATUS for a10
col STARTTIME for a20
set lines 500
set pages 200
select j.job_name,
js.text st,
to_char(to_date('01011970','DDMMYYYY')+(j.status_time-M.int_val)/86400,'DD/MM/YYYY HH24:MI:SS') debut
from
aedbadmin.ujo_jobst j , aedbadmin.ujo_intcodes js,aedbadmin.ujo_alamode M
where
M.TYPE='gmt_offset'
and j.status=js.code
and j.job_name like '%'
and status=6
and j.job_type=99
order by 3;
exit
EOF
}

terminatedclasse () {
while read a b c d
do
printf "%-65s%-11s%-10s%+9s\n" $a $b $c $d
done </tmp/job_terminated
}


jobstarting () {
echo "\nListe des Jobs en STARTING\n"
printf "%-65s%-11s%-17s\n" JOB_NAME STATUS STARTTIME
printf "%-65s%-11s%-17s\n" ---------------------------------------------------------------- ---------- -------------------
sqlplus -s atsreader/atsreader@P10973AP10 <<EOF |egrep -v "^ERROR|^ORA|rows|JOB_NAME|---------"  | sort -nk 3 |uniq |awk '{print $1,$2,$3,$4}' >/tmp/jobs_starting
col STATUS for a10
set lines 500
set pages 200
select j.job_name,
js.text st,
to_char(to_date('01011970','DDMMYYYY')+(j.status_time-M.int_val)/86400,'DD/MM/YYYY HH24:MI:SS') debut
from
aedbadmin.ujo_jobst j , aedbadmin.ujo_intcodes js,aedbadmin.ujo_alamode M
where
M.TYPE='gmt_offset'
and j.status=js.code
and j.job_name like '%'
and status=3
and j.job_type=99
order by 3;
exit
EOF
}

jobstartingclasse () {
while read a b c d
do
printf "%-65s%-11s%-10s%+9s\n" $a $b $c $d
done </tmp/jobs_starting
}

#rm des fichiers dans TMP
rmfic () {
if [[ -e /tmp/trigger_encours ]]
then
rm -f /tmp/trigger_encours
fi
if [[ -e /tmp/job_encours ]]
then
rm -f /tmp/job_encours
fi
if [[ -e /tmp/job_failure ]]
then
rm -f /tmp/job_failure
fi
if [[ -e /tmp/job_success ]]
then
rm -f /tmp/job_success
fi
if [[ -e /tmp/job_holde ]]
then
rm -f /tmp/job_holde
fi
if [[ -e /tmp/box_holde ]]
then
rm -f /tmp/box_holde
fi
if [[ -e /tmp/job_ice ]]
then
rm -f /tmp/job_ice
fi
if [[ -e /tmp/box_ice ]]
then
rm -f /tmp/box_ice
fi
if [[ -e /tmp/job_terminated ]]
then
rm -f /tmp/job_terminated
fi
if [[ -e /tmp/jobs_starting ]]
then
rm -f /tmp/jobs_starting
fi
}

