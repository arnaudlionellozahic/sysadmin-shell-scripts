#!/bin/ksh

#set -x
export DATEJOB=`date "+%Y%m%d.%H%M%S"`
export TEMP=/apps/meoatlas2/log/rapeurope/rapport_rapeur${DATEJOB}.log
exec 1>$TEMP
exec 2>&1
export DATEMAIL=`date "+%d/%m/%Y � %H:%M"`
export STAT="$(hostname)_stat.vacation.${DATEJOB}"
export SAUVE_TEMP="/apps/meoatlas2/rapports/rapeurope/stat/Rapport_job_temp_$DATEJOB"
export SAUVE="/apps/meoatlas2/rapports/rapeurope/stat/$STAT"
#export AUTOSERV=P20
#. /etc/auto.profile
export ORACLE_SID=P10973AP10
export ORACLE_BASE=/apps/oracle
export ORACLE_HOME=/apps/oracle/product/11204
export DATE=$(date +"%Y/%m/%d %T")
export DATEVEILLE="$(TZ=CET+24 date +"%Y/%m/%d %T")"
export FILE=/tmp/envoiemail.ma

#Lancement du script perl qui check tous le jobs en cours, running ou failure

/apps/meoatlas2/outils/autosys_rapjour.pl -j % -f "$DATEVEILLE" -t "$DATE" |grep -v BWAEP01 >$SAUVE_TEMP

#SED qui permet de rajouter les control-M pour les sauts a la ligne
if [[ -e $SAUVE_TEMP ]] then
sed '/^ *$/d' $SAUVE_TEMP >$SAUVE
fi

#Purge des fichiers de logs de plus de 7 jours
cd /apps/meoatlas2/rapports/rapeurope/stat/
find . -mtime +7 -exec rm {} \;

cd /apps/meoatlas2/log/rapeurope/
find . -mtime +7 -exec rm {} \;


rm $SAUVE_TEMP
