#!/bin/ksh
 set -x
#Fonction etat des tablespaces
echo test >/tmp/fred.log.3
etat_ts () {
echo TS >>/tmp/fred.log.3
rm /tmp/ts*lst  /tmp/ts*log 2>/dev/null
su - oracle << ts 2>/dev/null
5




export ORACLE_SID=atpr01
export ORACLE_HOME=/apps/oracle/product/11204
sqlplus -s "/as sysdba" << EOF >/tmp/ts.$$.log 2>&1

column TABLESPACE_NAME format A20
             set term off
             set echo off
             set feed off
             set pagesize 1000
             set verify off
             set linesize 100
spool /tmp/ts.$$.lst
select tablespace,used_mb,free_mb,total_mb,max_mb,pct_used,pct_used_max
                from (
                select
                        total.ts tablespace,
                        total.bytes - nvl(free.bytes,0) used_mb,
                        free.bytes free_mb,
                        total.bytes total_mb,
                        total.MAXBYTES max_mb,
                        100-ROUND( (nvl(free.bytes,0))/(total.bytes) * 100, 2) pct_used,
                        100-ROUND( (  nvl(total.MAXBYTES,0)  - (nvl(total.bytes,0)-nvl(free.bytes,0))  )/(total.MAXBYTES) * 100, 2) pct_used_max
                from
                        (select tablespace_name ts, round(sum(bytes)/1024/1024,2) bytes, round(sum(decode(MAXBYTES,0,BYTES,MAXBYTES))/1024/1024,2) MAXBYTES
                                from dba_data_files group by tablespace_name) total,
                        (select tablespace_name ts, round(sum(bytes)/1024/1024,2) bytes from dba_free_space group by tablespace_name) free
                where total.ts=free.ts(+) )
                order by 2 desc;
spool off
EOF
exit
ts

ERREUR_ORA=$(grep -E  "ORA-|ERROR" /tmp/ts.$$.log)
if [[ -z "$ERREUR_ORA" ]] then
print "\n\t ETAT DES TABLESPACES DE LA BASE DE PRODUCTION\n"
cat  /tmp/ts.$$.lst | awk '
 NR<=3 { print $0 }
 NR>3 {  if ($NF > 80)
 {
 print $0,"seuil depasse  etat critique "  }
 else
 {
 print $0
 }
 }'
fi

}

echo teste >>/tmp/fred.log.3
#Fonction etat des jobs
etat_job () {
print "\n\t\tRAPPORT ATLAS Nouvelle Cal�donie du $jour"
echo etatjob >>/tmp/fred.log.3
#Recherche du debut et fin du JEC2
DEBJEC2=$(grep -w "jec2${suffenv}" $RESULT_RAP  |awk -F";" '{print $3}' |awk '{print $2}' |tail -1)
FINJEC2=$(grep -w "jec2${suffenv}" $RESULT_RAP  |awk -F";" '{print $4}' |awk '{print $2}' |tail -1)
echo j9f1 >>/tmp/fred.log.3
#Recherche des d�but et fins de sauvegarde
DEBJ9F1=$(grep -w "j9f1${suffenv}" $RESULT_RAP |awk -F";" '{print $3}' |awk '{print $2}' |tail -1)
FINJ9F1=$(grep -w "j9f1${suffenv}" $RESULT_RAP |awk -F";" '{print $4}' |awk '{print $2}' |tail -1)
DEBJ9F2=$(grep -w "j9f2${suffenv}" $RESULT_RAP |awk -F";" '{print $3}' |awk '{print $2}' |tail -1)
FINJ9F2=$(grep -w "j9f2${suffenv}" $RESULT_RAP |awk -F";" '{print $4}' |awk '{print $2}' |tail -1)

#Heure Ouverture du TP
OUV=$(grep -w jtp1${suffenv}_jcics1_01 $RESULT_RAP |awk -F";" '{print $4}' |awk '{print $2}' |tail -1)
OUVF=$(echo ${OUV%:*} |tr ':' 'h')
print "\n\nOuverture TP : $OUVF"

#Heure Fermeture du TP
FERM=$(grep -w jtp2${suffenv}_jcics2_01 $RESULT_RAP |awk -F";" '{print $4}' |awk '{print $2}' |tail -1)
FERMF=$(echo ${FERM%:*} |tr ':' 'h')
print "Fermeture TP : $FERMF"

#Heures du debut et fin du Finjour
DEBFJ=$(grep -w jfja${suffenv} $RESULT_RAP |awk -F";" '{print $3}' |awk '{print $2}' |tail -1)
FINFJ=$(grep -w jfj1${suffenv} $RESULT_RAP |awk -F";" '{print $4}' |awk '{print $2}' |tail -1)
FINTOT=$(grep -w jtp1${suffenv} $RESULT_RAP |awk -F";" '{print $4}' |awk '{print $2}' |tail -1)
echo DEB >>/tmp/fred.log.3
#Remise en forme de l'affichage
DEBJ9F1F=$(echo ${DEBJ9F1%:*} |tr ':' 'h')
FINJ9F1F=$(echo ${FINJ9F1%:*} |tr ':' 'h')
DEBJ9F2F=$(echo ${DEBJ9F2%:*} |tr ':' 'h')
FINJ9F2F=$(echo ${FINJ9F2%:*} |tr ':' 'h')
DEBFJF=$(echo ${DEBFJ%:*} |tr ':' 'h')
FINFJF=$(echo ${FINFJ%:*} |tr ':' 'h')
FINTOTF=$(echo ${FINTOT%:*} |tr ':' 'h')
DEBJEC2F=$(echo ${DEBJEC2%:*} |tr ':' 'h')
FINJEC2F=$(echo ${FINJEC2%:*} |tr ':' 'h')
print "D�but sauvegarde avant FINJOUR � : $DEBJ9F1F"
print "Fin sauvegarde avant FINJOUR � : $FINJ9F1F"
print "D�but FINJOUR � : $DEBFJF"
print "Fin FINJOUR �   : $FINFJF"
print "D�but sauvegarde apres FINJOUR    : $DEBJ9F2F"
print "Fin sauvegarde apr�s FINJOUR      : $FINJ9F2F"
print "D�but JEC2 �   : $DEBJEC2F"
print "Fin JEC2 �   : $FINJEC2F"

OUV2=$(grep "jtp1${suffenv}_jcics1_01" $RESULT_RAP |grep $jour2 |awk -F";" '{print $4}' |awk '{print $2}' |tail -1)
OUV2F=$(echo ${OUV2%:*} |tr ':' 'h')
if [[ -n $OUV2F ]]
then
print ""
else
print ""
fi

typeset -LZ10 NBTOT=
NBTOT=$(grep -v  "^.\{9,11\};" $RESULT_RAP  |grep -v "^sb"| wc -l)
NBTOTSPE=$(grep -v  "^.\{9,11\};" $RESULT_RAP  |grep -v "^sb" |awk -F";" '{print $1,$3}' | grep -E "jw|mw|dw|jv|mv|dv"  |awk '{print $1,$3}' |sort -uk 2| wc -l)
print "\nNombre total de jobs trait�s : $NBTOT "
print "dont jobs sp�cifiques : $NBTOTSPE"
NBTOTSTD=$(($NBTOT-$NBTOTSPE))
echo $NBTOTSTD > $REPLOG/log$site.$JJ$MM$YY
echo $NBTOTSPE >> $REPLOG/log$site.$JJ$MM$YY
NBTOTSTD=$(($NBTOT-$NBTOTSPE))
echo $NBTOTSTD >> $REPLOG/log$site.$JJ$MM$YY

export NBTOTAB=0
export NBTOTABSPE=0

#typeset -LZ5 NBTOTAB=
NBTOTAB=$(grep FAILURE $RESULT_RAP |grep -v "^.\{9,11\};" |awk -F";" '{print $1}' |sort -u |wc -l)
print "\nNombre total de jobs en abort : $NBTOTAB "

if [[ $NBTOTAB -ne 0 ]]
then
NBTOTABSPE=$(grep FAILURE $RESULT_RAP |grep -v "^.\{9,11\};" | grep -E "jv|mv|dv|jw|mw|dw" |awk -F";" '{print $1}' |sort -u |wc -l)
print "dont jobs sp�cifiques : $NBTOTABSPE  "
print "\nListe des aborts specifiques \n"
grep FAILURE $RESULT_RAP |grep -v "^.\{9,11\};" | grep -E "jv|mv|dv|jw|mw|dw" | awk -F"_" '{print $2,$1,$3}'  |awk -F";" '{print $1,$4}' |awk '{print "job "$1" de la BOX "$2" le "$4" a "$5}'
print "\nListe des aborts standards"
grep FAILURE $RESULT_RAP |grep -v "^.\{9,11\};" | grep -Ev "jv|mv|dv|jw|mw|dw" | awk -F"_" '{print $2,$1,$3}'  |awk -F";" '{print $1,$4}' |awk '{print "job "$1" de la BOX "$2" le "$4" a "$5}'
fi

echo $NBTOTAB >> $REPLOG/log$site.$JJ$MM$YY
echo $NBTOTABSPE >> $REPLOG/log$site.$JJ$MM$YY
echo $NBTOTAB " " $NBTOTABSPE
export NBTOTABSTD=$(($NBTOTAB-$NBTOTABSPE))
echo $NBTOTABSTD >> $REPLOG/log$site.$JJ$MM$YY

#Recherche du nombre de mouvements

export MEO_WORK=/apps/meoatlas2/outils
export MEO_TMP=/apps/meoatlas2/log/cal_mvt_dts.tmp

cd /apps/arch/imp-0

CHK_MVT=$(ls -d JASF31*sys* |wc -l)
if [[ $CHK_MVT -eq 1 ]] then
        cat JASF31*sys* > $MEO_TMP
        NB_MVT=$(sed s/^M// $MEO_TMP |grep HM06 |awk '{print $2}' |awk '{sum += $1} END {print sum}')
else
        NB_MVT="ERR"
fi

CHK_DTS=$(ls -d DAS550.dts1.sysout* |wc -l)
if [[ $CHK_DTS -eq 1 ]] then
        sed s/^M// DAS550.dts1.sysout* > $MEO_TMP
        NB_DTS=$(sed s/^M// $MEO_TMP |grep DT38 |grep "RECHERCHE DU SUIVANT" |awk '{print $2}' |awk '{sum += $1} END {print sum}')
        DATE_TRT=$(sed s/^M// $MEO_TMP |grep "DATE/HEURE" |head -1 |awk '{print $15" "$16}')
else
        NB_DTS="ERR"
        DATE_TRT="ERR"
fi

echo "
Nombre de Mouvement : $NB_MVT
Nombre de Transfert de si�ge : $NB_DTS"


#Recherche des traitements supplementaire ayant tournes
print "Traitements suppl�mentaires\n"
for jobset in arz1 dar1 dar6 dpu7 dpu8 dpu9 dpuc dsu1 m9f1 m9k2 map1 mdi1 mec1 mec2 meg1 meg2 meg3 meg4 meg6 mex1 min1 mrv1 tec1 tex1
do
if (grep  "SUCCESS" $RESULT_RAP | grep -w ${jobset}${suffenv} 1> /dev/null)
then
grep "SUCCESS" $RESULT_RAP | grep -w ${jobset}${suffenv} |awk -F";" '{print $3}' |awk '{print $2}' |sort -u|while read  row1
do
DEBJOBSET=$row1
FINJOBSET=$(grep "SUCCESS" $RESULT_RAP | grep -w ${jobset}${suffenv} |awk -F";" '{print $4}' |awk '{print $2}' |sort -u|head -$count|tail -1)
DEBJOBSETF=$(echo ${DEBJOBSET%:*} |tr ':' 'h')
FINJOBSETF=$(echo ${FINJOBSET%:*} |tr ':' 'h')
count=$(($count+1))
print "Debut du jobset $jobset a $DEBJOBSETF et fin a $FINJOBSETF\n"
done
fi
done

if (grep  "SUCCESS" $RESULT_RAP | grep "dvtb1" 1> /dev/null)
then
        DEBJOBSET=$(grep "SUCCESS" $RESULT_RAP  | grep "dvtb1" |awk -F";" '{print $3}' |awk '{print $2}')
        FINJOBSET=$(grep "SUCCESS" $RESULT_RAP  | grep "dvtb1" |awk -F";" '{print $4}' |awk '{print $2}')
        DEBJOBSETF=$(echo ${DEBJOBSET%:*} |tr ':' 'h')
        FINJOBSETF=$(echo ${FINJOBSET%:*} |tr ':' 'h')
        print "\nChargement tables avant FINJOUR effectu� (d�but � $DEBJOBSETF et fin � $FINJOBSETF)"
else
        print "\nAucun chargement de tables avant FINJOUR effectu�"
fi

if (grep  "SUCCESS" $RESULT_RAP | grep "dvtb2" 1> /dev/null)
then
        DEBJOBSET=$(grep "SUCCESS" $RESULT_RAP  | grep "dvtb2" |awk -F";" '{print $3}' |awk '{print $2}')
        FINJOBSET=$(grep "SUCCESS" $RESULT_RAP  | grep "dvtb2" |awk -F";" '{print $4}' |awk '{print $2}')
        DEBJOBSETF=$(echo ${DEBJOBSET%:*} |tr ':' 'h')
        FINJOBSETF=$(echo ${FINJOBSET%:*} |tr ':' 'h')
        print "\nChargement tables apr�s FINJOUR effectu� (d�but � $DEBJOBSETF et fin � $FINJOBSETF)"
else

        print "\nAucun chargement de tables apr�s FINJOUR effectu�"
fi
}

#Etat des FS
etat_FS () {
echo FS >>/tmp/fred.log.3
print "\n\t ETAT DES SYSTEMES DE FICHIERS "
IMP0=$(df -k $A2_IMP | awk '{ print $1 " " $4"  " $6"  " $7}')
IMP1=$(du -k $A2_IMP)
print "\nEtat de /apps/atlas/atals2v0/uf1/data1/imp  : "
print "\n$IMP0"
print "Etat de /apps/atlas/atals2v0/uf1/data1/imp en nombre de bloc de 1024 bits : "
print "\n$IMP1"

FIC0=$(df -k /$A2_FIC|awk '{print $1 "  " $4 "  " $6 "  " $7}')

FIC1=$(du -k $A2_FIC)
print "Etat de /apps/atlas/atals2v0/uf1/data1/fic  : "
print "\n$FIC0"
print "\nEtat de /apps/atlas/atals2v0/uf1/data1/fic en nombre de blocs de 1024 bits  : "
print "\n$FIC1"

print "\nEtat de /ficsav"
FIC3=$(df -k /ficsav |awk '{ print $1 "  " $4 "  " $6 "  " $7 }')
print "\n$FIC3"
FIC4=$(du -k /apps/atlas/atlas2v0/uf1/ficsav)
print "\n Etat de /ficsav en nombre de blocs de 1024 bits"
print "\n$FIC4"
}

#Etat du CFT
etat_CFT () {
echo CFT >>/tmp/fred.log.3
cftutil listcat type=all
FINJ=$(echo ${FINFJ%.*} |tr '.' ':')
echo "$(date)   $FINJ" >>/apps/sys/shell/exploit/statistique
print "\n"
}

