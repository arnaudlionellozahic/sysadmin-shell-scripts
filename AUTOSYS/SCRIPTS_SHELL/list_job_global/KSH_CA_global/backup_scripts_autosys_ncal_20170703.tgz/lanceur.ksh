#!/bin/ksh
set -x
su - oracle -c /ficsav/EQUIPE_MEO/arnaud/rapport.ksh <<4
4

