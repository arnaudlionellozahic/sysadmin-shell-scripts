#!/bin/ksh -x

entete ()
{
echo "----------------------------------------------------------------------------------------------------------"
echo "----------------------------------------------------------------------------------------------------------"
echo ""
echo "#### DEBUT JOB ${CTM0} $(date "+%Y%m%d-%H%M%S") ####"
echo ""
echo "Report of the autosys jobs le $(date "+%Y%m%d a %H%M%S")"
echo ""
echo "###################################################################"
}

###########################################################################################

jobs_report_FA ()
{
perl -w /ficsav/EQUIPE_MEO/arnaud/autosys_reporting_job_FA.pl -j % -f "$DATEVEILLE 08:00:00" -t "$DATE 08:10:00"
}

###########################################################################################

jobs_report_RU ()
{
perl -w /ficsav/EQUIPE_MEO/arnaud/autosys_reporting_job_RU.pl -j % -f "$DATEVEILLE 08:00:00" -t "$DATE 08:10:00"
}

###########################################################################################

verif_jobs ()
{
if [ `awk '/FAILURE/' ${FILE_FA} | wc -l` -lt 1 ]; then
  echo ""
  echo "Pas de jobs en erreur"
        else
        echo ""
        echo "There are `awk '/FAILURE/' ${FILE_FA} | wc -l | sed 's/[  ]*[ ]*//g;'` jobs in error"
        cat ${FILE_FA}
fi

echo ""
echo "###################################################################"

if [ `awk '/RUNNING/' ${FILE_RU} | wc -l` -lt 1 ]; then
  echo ""
  echo "Pas de jobs en running"
        else
        echo ""
        echo "There are `awk '/RUNNING/' ${FILE_RU} | wc -l | sed 's/[  ]*[ ]*//g;'` jobs running"
        cat ${FILE_RU}
        echo ""
        echo "###################################################################"
        echo ""
        echo "#### FIN JOB ${CTM0} $(date "+%Y%m%d-%H%M%S") ####"
        echo ""
        echo "----------------------------------------------------------------------------------------------------------"
        echo "----------------------------------------------------------------------------------------------------------"
        echo "exit ${?}"
        exit ${?}
fi
}

###########################################################################################

fonc_mail ()
{
uuencode ${FILE_LOG} ${FILE_LOG} | mailx -r "480076" -s "Rapport Jobs Autosys en Erreur et Running ${_ODATE}" arnaud.lozahic@externe.bnpparibas.com
}

###########################################################################################
#
#Main

REP=/ficsav/EQUIPE_MEO/arnaud
ODATE=`date +"%Y%m%d"`
_ODATE=`date +"%d/%m/%Y"`
DATEVEILLE="$(TZ=MET+24 date +"%Y/%m/%d")"
DATE=`date "+%Y/%m/%d"`
FILE_FA=${REP}/jobs_error.txt_KSH
FILE_RU=${REP}/jobs_running.txt_KSH
FILE_LOG=${REP}/report.log_KSH
export ORACLE_SID=Q10973AP10
export ORACLE_BASE=/apps/oracle
export ORACLE_HOME=/apps/oracle/product/11204

entete | tee ${FILE_LOG}
jobs_report_FA | tee ${FILE_FA}
jobs_report_RU | tee ${FILE_RU}
verif_jobs | tee -a ${FILE_LOG}
rm -f ${FILE_FA} ${FILE_RU}

ksh ${REP}/html.ksh
