#!/bin/ksh -x

DATEVEILLE="$(TZ=MET+24 date +"%Y/%m/%d")"
DATE=`date "+%Y/%m/%d"`
DATEJOB=`date "+%Y%m%d"`
SAUVE_TEMP="/ficsav/EQUIPE_MEO/arnaud/Rapport_job_temp"
SAUVE="/ficsav/EQUIPE_MEO/arnaud/Rapport_job_$DATEJOB"
export ORACLE_SID=Q10973AP10
export ORACLE_BASE=/apps/oracle
export ORACLE_HOME=/apps/oracle/product/11204

#perl -w /ficsav/EQUIPE_MEO/arnaud/autosys_reporting_job.pl -j % -f "$DATEVEILLE 08:00:00" -t "$DATE 08:10:00" |tee $SAUVE_TEMP

#SED qui permet de rajouter les control-M pour les sauts a la ligne

if [[ -e $SAUVE_TEMP ]] then
sed '/^ *$/d' $SAUVE_TEMP >$SAUVE
cp -p $SAUVE ${SAUVE}.csv
grep -v "BWAEP01" $SAUVE >${SAUVE_BICI}.csv
fi

FAIL=$(grep FAILURE $SAUVE_TEMP)
FAIL_NUM=$(grep FAILURE $SAUVE_TEMP |wc -l)
RUN=$(grep RUNNING $SAUVE_TEMP)
RUN_NUM=$(grep RUNNING $SAUVE_TEMP |wc -l)

uuencode ${SAUVE}.csv ${SAUVE}.csv | mailx -s "Rapport Jobs ${DATE}" arnaud.lozahic@externe.bnpparibas.com

