<instruction>
if ERRORLEVEL 3 GOTO FIN
tsend
:FIN
exit