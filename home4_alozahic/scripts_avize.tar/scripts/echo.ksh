#!/bin/ksh
PAR=$*
for i in $PAR
do
echo $i
done
