echo "Job OK"
if ERRORLEVEL 3 GOTO FIN
tsend
:FIN
exit