#!/bin/ksh
set -xv
PAR1=$1
PAR2=$2
PAR3=$3
log=/home4/alozahic/Linux/athis/Ver544/scripts/test_parametres.log
echo "---- `date +'%F_%T'` ----" >> $log
echo "" | awk -v val="$PAR" '{printf("ligne parametres :>%s<\n", val)}' >> $log

while getopts n:e:E: Option ; do
  case ${Option} in
     n) OPTION_N=${OPTARG};;
     e) OPTION_e=${OPTARG};;
     E) OPTION_E=${OPTARG};;
  esac
done
echo "parametres apres traitement : n=>$OPTION_N< e=>$OPTION_e< E=>$OPTION_E<" >> $log
exit 0

